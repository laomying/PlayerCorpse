package com.corpse.entity;

import com.mojang.authlib.GameProfile;
import java.util.EnumMap;
import net.minecraft.class_1007;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_638;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public class CorpseEntityRenderer extends class_897<CorpseEntity> {

    private static final class_310 MC = class_310.method_1551();
    private static final class_2960 FALLBACK_TEXTURE = class_2960.method_60656(
            "textures/entity/player/wide/steve.png");

    public CorpseEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 getTextureLocation(CorpseEntity entity) {
        return FALLBACK_TEXTURE;
    }

    @Override
    public void render(CorpseEntity entity, float yaw, float tickDelta, class_4587 stack,
                       class_4597 source, int packedLight) {
        if (entity.isSkeleton()) {
            return;
        }

        GameProfile profile = new GameProfile(entity.getPlayerUuid(), entity.getPlayerName());
        EnumMap<class_1304, class_1799> equipment = entity.getEquipment();

        DummyPlayerEntity dummyPlayer = new DummyPlayerEntity(
                (class_638) entity.method_37908(),
                profile,
                equipment
        );

        class_1007 playerRenderer = (class_1007) MC.method_1561()
                .method_3953(dummyPlayer);
        if (playerRenderer == null) {
            return;
        }

        stack.method_22903();

        // Rotate to face camera direction
        stack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - yaw));
        // Lay player flat on back
        stack.method_22907(class_7833.field_40714.rotationDegrees(-90F));
        stack.method_22904(0.0D, -1.0D, 0.125D);

        // Delegate to vanilla player renderer — this renders skin, cape, armor layers, held items
        playerRenderer.method_4215(dummyPlayer, 0F, tickDelta, stack, source, packedLight);

        stack.method_22909();
    }
}
