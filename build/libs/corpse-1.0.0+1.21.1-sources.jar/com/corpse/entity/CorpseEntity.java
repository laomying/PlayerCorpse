package com.corpse.entity;

import com.corpse.CorpseMod;
import com.corpse.gui.CorpseScreenHandler;
import net.minecraft.class_1262;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3908;
import net.minecraft.class_8103;
import net.minecraft.world.entity.*;
import java.util.EnumMap;
import java.util.UUID;

public class CorpseEntity extends class_1297 implements class_3908 {

    private static final class_2940<String> PLAYER_NAME = class_2945.method_12791(CorpseEntity.class, class_2943.field_13326);
    private static final class_2940<String> PLAYER_UUID_STR = class_2945.method_12791(CorpseEntity.class, class_2943.field_13326);
    private static final class_2940<Boolean> IS_SKELETON = class_2945.method_12791(CorpseEntity.class, class_2943.field_13323);
    private static final class_2940<String> EQUIPMENT_DATA = class_2945.method_12791(CorpseEntity.class, class_2943.field_13326);

    private class_2371<class_1799> mainInventory;
    private class_2371<class_1799> armorInventory;
    private class_2371<class_1799> offHandInventory;
    private EnumMap<class_1304, class_1799> equipment;

    private int age;
    private int emptyAge;

    private static final int SKELETON_TIME = 72000;
    private static final int EMPTY_DESPAWN_TIME = 6000;

    public CorpseEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
        mainInventory = class_2371.method_10213(36, class_1799.field_8037);
        armorInventory = class_2371.method_10213(4, class_1799.field_8037);
        offHandInventory = class_2371.method_10213(1, class_1799.field_8037);
        equipment = new EnumMap<>(class_1304.class);
        field_23807 = true;
        emptyAge = -1;
    }

    public CorpseEntity(class_1937 level) {
        this(CorpseMod.CORPSE_ENTITY_TYPE, level);
    }

    public static CorpseEntity createFromPlayer(class_3222 player) {
        CorpseEntity corpse = new CorpseEntity(player.method_37908());

        corpse.setPlayerName(player.method_7334().getName());
        corpse.setPlayerUuidStr(player.method_7334().getId().toString());
        corpse.method_5814(player.method_23317(), Math.max(player.method_23318(), player.method_37908().method_31607()), player.method_23321());
        corpse.method_36456(player.method_36454());

        for (class_1304 slot : class_1304.values()) {
            class_1799 stack = player.method_6118(slot).method_7972();
            if (!stack.method_7960()) {
                corpse.equipment.put(slot, stack);
            }
        }

        if (!player.method_37908().method_8450().method_8355(net.minecraft.class_1928.field_19389)) {
            for (int i = 0; i < 36; i++) {
                corpse.mainInventory.set(i, player.method_31548().field_7547.get(i).method_7972());
                player.method_31548().field_7547.set(i, class_1799.field_8037);
            }
            for (int i = 0; i < 4; i++) {
                corpse.armorInventory.set(i, player.method_31548().field_7548.get(i).method_7972());
                player.method_31548().field_7548.set(i, class_1799.field_8037);
            }
            corpse.offHandInventory.set(0, player.method_31548().field_7544.get(0).method_7972());
            player.method_31548().field_7544.set(0, class_1799.field_8037);
        }

        corpse.syncEquipmentData();
        return corpse;
    }

    private void syncEquipmentData() {
        // Simple text format: "SLOT:item_id;SLOT:item_id;..."
        // Example: "HEAD:iron_helmet;CHEST:iron_chestplate;LEGS:iron_leggings;FEET:iron_boots"
        StringBuilder sb = new StringBuilder();
        for (class_1304 slot : class_1304.values()) {
            class_1799 stack = equipment.get(slot);
            if (stack != null && !stack.method_7960()) {
                if (sb.length() > 0) sb.append(';');
                sb.append(slot.name()).append(':')
                        .append(net.minecraft.class_7923.field_41178
                                .method_10221(stack.method_7909()).method_12832());
            }
        }
        field_6011.method_12778(EQUIPMENT_DATA, sb.toString());
    }

    public EnumMap<class_1304, class_1799> getEquipment() {
        if (method_37908().field_9236) {
            String equipStr = field_6011.method_12789(EQUIPMENT_DATA);
            EnumMap<class_1304, class_1799> eq = new EnumMap<>(class_1304.class);
            if (equipStr.isEmpty()) return eq;
            try {
                for (String part : equipStr.split(";")) {
                    String[] kv = part.split(":", 2);
                    if (kv.length != 2) continue;
                    class_1304 slot = class_1304.valueOf(kv[0]);
                    net.minecraft.class_1792 item =
                            net.minecraft.class_7923.field_41178
                                    .method_10223(net.minecraft.class_2960
                                            .method_60656(kv[1]));
                    if (item != null) {
                        eq.put(slot, new class_1799(item));
                    }
                }
            } catch (Exception e) {
                CorpseMod.LOGGER.warn("Failed to parse equipment: {}", e.getMessage());
            }
            return eq;
        }
        return equipment;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (!method_5740()) {
            double yMotion;
            class_243 motion = method_18798();
            if (method_5777(class_3486.field_15517) || method_5777(class_3486.field_15518)) {
                yMotion = (motion.field_1351 < 0.03D) ? (motion.field_1351 + (motion.field_1351 < 0.03D ? 0.01D : 0D)) : (motion.field_1351 + 5E-4D);
            } else {
                yMotion = Math.max(-2D, motion.field_1351 - 0.0625D);
            }
            method_18800(motion.field_1352 * 0.75D, yMotion, motion.field_1350 * 0.75D);

            if (method_23318() < method_37908().method_31607()) {
                method_5859(method_23317(), method_37908().method_31607(), method_23321());
            }

            method_5784(class_1313.field_6308, method_18798());
        }

        if (method_37908().field_9236) {
            return;
        }

        age++;

        if (age >= SKELETON_TIME && !isSkeleton()) {
            setIsSkeleton(true);
        }

        boolean empty = isInventoryEmpty();
        if (empty && emptyAge < 0) {
            emptyAge = age;
        } else if (!empty) {
            emptyAge = -1;
        }

        if (empty && emptyAge >= 0 && age - emptyAge >= EMPTY_DESPAWN_TIME) {
            method_31472();
        }
    }

    public boolean isInventoryEmpty() {
        for (class_1799 stack : mainInventory) {
            if (!stack.method_7960()) return false;
        }
        for (class_1799 stack : armorInventory) {
            if (!stack.method_7960()) return false;
        }
        for (class_1799 stack : offHandInventory) {
            if (!stack.method_7960()) return false;
        }
        return true;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (source.method_48789(class_8103.field_42246) && amount >= 2F) {
            method_31472();
            return true;
        }
        return false;
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (!method_37908().field_9236 && player instanceof class_3222 serverPlayer) {
            serverPlayer.method_17355(this);
        }
        return class_1269.field_5812;
    }

    // MenuProvider implementation
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CorpseScreenHandler(syncId, playerInventory, this);
    }

    @Override
    public class_2561 method_5476() {
        String name = getPlayerName();
        if (name == null || name.trim().isEmpty()) {
            return class_2561.method_43471("entity.corpse.corpse");
        }
        return class_2561.method_43469("entity.corpse.corpse_of", name);
    }

    @Override
    public boolean method_5863() {
        return method_5805();
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5862() {
        return false;
    }

    public String getPlayerName() {
        return field_6011.method_12789(PLAYER_NAME);
    }

    private void setPlayerName(String name) {
        field_6011.method_12778(PLAYER_NAME, name);
    }

    public UUID getPlayerUuid() {
        String uuidStr = getPlayerUuidStr();
        if (uuidStr.isEmpty()) return new UUID(0, 0);
        try {
            return UUID.fromString(uuidStr);
        } catch (IllegalArgumentException e) {
            return new UUID(0, 0);
        }
    }

    public String getPlayerUuidStr() {
        return field_6011.method_12789(PLAYER_UUID_STR);
    }

    private void setPlayerUuidStr(String uuidStr) {
        field_6011.method_12778(PLAYER_UUID_STR, uuidStr);
    }

    public boolean isSkeleton() {
        return field_6011.method_12789(IS_SKELETON);
    }

    private void setIsSkeleton(boolean skeleton) {
        field_6011.method_12778(IS_SKELETON, skeleton);
    }

    public class_2371<class_1799> getMainInventory() {
        return mainInventory;
    }

    public class_2371<class_1799> getArmorInventory() {
        return armorInventory;
    }

    public class_2371<class_1799> getOffHandInventory() {
        return offHandInventory;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(PLAYER_NAME, "");
        builder.method_56912(PLAYER_UUID_STR, "");
        builder.method_56912(IS_SKELETON, false);
        builder.method_56912(EQUIPMENT_DATA, "");
    }

    @Override
    protected void method_5749(class_2487 compound) {
        mainInventory = class_2371.method_10213(36, class_1799.field_8037);
        armorInventory = class_2371.method_10213(4, class_1799.field_8037);
        offHandInventory = class_2371.method_10213(1, class_1799.field_8037);

        if (compound.method_10545("MainInventory")) {
            class_1262.method_5429(compound.method_10562("MainInventory"), mainInventory, method_56673());
        }
        if (compound.method_10545("ArmorInventory")) {
            class_1262.method_5429(compound.method_10562("ArmorInventory"), armorInventory, method_56673());
        }
        if (compound.method_10545("OffHandInventory")) {
            class_1262.method_5429(compound.method_10562("OffHandInventory"), offHandInventory, method_56673());
        }

        age = compound.method_10550("Age");
        emptyAge = compound.method_10550("EmptyAge");

        setPlayerName(compound.method_10558("PlayerName"));
        setPlayerUuidStr(compound.method_10558("PlayerUUID"));
        setIsSkeleton(compound.method_10577("Skeleton"));

        equipment = new EnumMap<>(class_1304.class);
        if (compound.method_10545("Equipment")) {
            class_2487 equipTag = compound.method_10562("Equipment");
            for (class_1304 slot : class_1304.values()) {
                if (equipTag.method_10545(slot.name())) {
                    equipment.put(slot, class_1799.method_57359(method_56673(), equipTag.method_10562(slot.name())));
                }
            }
        }
        syncEquipmentData();
    }

    @Override
    protected void method_5652(class_2487 compound) {
        class_2487 mainTag = new class_2487();
        class_1262.method_5426(mainTag, mainInventory, method_56673());
        compound.method_10566("MainInventory", mainTag);

        class_2487 armorTag = new class_2487();
        class_1262.method_5426(armorTag, armorInventory, method_56673());
        compound.method_10566("ArmorInventory", armorTag);

        class_2487 offTag = new class_2487();
        class_1262.method_5426(offTag, offHandInventory, method_56673());
        compound.method_10566("OffHandInventory", offTag);

        compound.method_10569("Age", age);
        compound.method_10569("EmptyAge", emptyAge);
        compound.method_10582("PlayerName", getPlayerName());
        compound.method_10582("PlayerUUID", getPlayerUuidStr());
        compound.method_10556("Skeleton", isSkeleton());

        class_2487 equipTag = new class_2487();
        for (class_1304 slot : class_1304.values()) {
            class_1799 stack = equipment.get(slot);
            if (stack != null && !stack.method_7960()) {
                class_2487 itemTag = new class_2487();
                stack.method_57376(method_56673(), itemTag);
                equipTag.method_10566(slot.name(), itemTag);
            }
        }
        compound.method_10566("Equipment", equipTag);
    }

    @Override
    public void method_5650(class_5529 reason) {
        if (!method_37908().field_9236) {
            for (class_1799 stack : mainInventory) {
                if (!stack.method_7960()) {
                    method_5775(stack);
                }
            }
            for (class_1799 stack : armorInventory) {
                if (!stack.method_7960()) {
                    method_5775(stack);
                }
            }
            for (class_1799 stack : offHandInventory) {
                if (!stack.method_7960()) {
                    method_5775(stack);
                }
            }
        }
        super.method_5650(reason);
    }
}
