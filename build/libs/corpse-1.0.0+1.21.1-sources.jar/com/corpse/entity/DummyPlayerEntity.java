package com.corpse.entity;

import com.mojang.authlib.GameProfile;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_638;
import net.minecraft.class_745;

/**
 * A client-side dummy player used to render the player's skin on the corpse.
 * Extends RemotePlayer to get the skin rendering through PlayerRenderer.
 * This entity never exists on the server - it's purely for client rendering.
 */
public class DummyPlayerEntity extends class_745 {

    public DummyPlayerEntity(class_638 level, GameProfile gameProfile,
                             EnumMap<class_1304, class_1799> equipment) {
        super(level, gameProfile);

        // Set equipment for rendering on the corpse body
        for (Map.Entry<class_1304, class_1799> entry : equipment.entrySet()) {
            method_5673(entry.getKey(), entry.getValue());
        }

        // Position: the actual renderer handles positioning, so set to origin
        method_5814(0.0D, 0.0D, 0.0D);
        field_6014 = 0.0D;
        field_6036 = 0.0D;
        field_5969 = 0.0D;
    }

    @Override
    public boolean method_7325() {
        return false;
    }
}
