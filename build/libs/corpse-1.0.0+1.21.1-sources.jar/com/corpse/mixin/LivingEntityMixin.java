package com.corpse.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin that cancels the vanilla item drop on player death.
 * The CorpseEntity will handle item storage instead.
 */
@Mixin(class_1309.class)
public class LivingEntityMixin {

    /**
     * Cancel dropAllDeathLoot for players so items stay in the inventory.
     * The DeathEventHandler will create a CorpseEntity that stores the items.
     */
    @Inject(method = "dropAllDeathLoot", at = @At("HEAD"), cancellable = true)
    private void corpse_cancelDeathDrops(class_3218 level, class_1282 damageSource, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self instanceof class_3222) {
            ci.cancel();
        }
    }
}
