package com.corpse.event;

import com.corpse.CorpseMod;
import com.corpse.entity.CorpseEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_3222;

public class DeathEventHandler {

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof class_3222 player) {
                // At this point, the mixin has cancelled vanilla item drops
                // The player's inventory is still intact
                CorpseMod.LOGGER.info("Player {} died, creating corpse at {}", 
                        player.method_7334().getName(), player.method_24515());

                CorpseEntity corpse = CorpseEntity.createFromPlayer(player);
                player.method_37908().method_8649(corpse);

                CorpseMod.LOGGER.info("Corpse created with {} items", 
                        corpse.getMainInventory().stream().filter(s -> !s.method_7960()).count()
                        + corpse.getArmorInventory().stream().filter(s -> !s.method_7960()).count()
                        + corpse.getOffHandInventory().stream().filter(s -> !s.method_7960()).count());
            }
        });
    }
}
