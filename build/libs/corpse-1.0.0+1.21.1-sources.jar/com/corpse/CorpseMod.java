package com.corpse;

import com.corpse.entity.CorpseEntity;
import com.corpse.event.DeathEventHandler;
import com.corpse.gui.CorpseScreenHandler;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CorpseMod implements ModInitializer {

    public static final String MOD_ID = "corpse";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1299<CorpseEntity> CORPSE_ENTITY_TYPE = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(MOD_ID, "corpse"),
            class_1299.class_1300.<CorpseEntity>method_5903(CorpseEntity::new, class_1311.field_17715)
                    .method_17687(2F, 0.5F)
                    .method_55687(0.25F)
                    .method_5905("corpse")
    );

    public static final class_3917<CorpseScreenHandler> CORPSE_SCREEN_HANDLER = class_2378.method_10230(
            class_7923.field_41187,
            class_2960.method_60655(MOD_ID, "corpse_inventory"),
            new class_3917<>(CorpseScreenHandler::new, class_7701.field_40183)
    );

    @Override
    public void onInitialize() {
        LOGGER.info("Corpse Mod initializing...");

        DeathEventHandler.register();

        LOGGER.info("Corpse Mod initialized!");
    }
}
