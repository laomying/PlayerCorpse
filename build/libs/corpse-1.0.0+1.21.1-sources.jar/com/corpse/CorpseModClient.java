package com.corpse;

import com.corpse.entity.CorpseEntityRenderer;
import com.corpse.gui.CorpseScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_3929;

public class CorpseModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(CorpseMod.CORPSE_ENTITY_TYPE, CorpseEntityRenderer::new);

        class_3929.method_17542(CorpseMod.CORPSE_SCREEN_HANDLER, CorpseScreen::new);

        CorpseMod.LOGGER.info("Corpse Mod client initialized!");
    }
}
