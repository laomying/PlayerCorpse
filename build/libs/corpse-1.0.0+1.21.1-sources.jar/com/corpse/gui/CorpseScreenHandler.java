package com.corpse.gui;

import com.corpse.CorpseMod;
import com.corpse.entity.CorpseEntity;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2540;

public class CorpseScreenHandler extends class_1703 {

    private final class_1263 corpseContainer;
    private final CorpseEntity corpseEntity; // null on client

    // Client-side constructor (called by MenuType factory)
    public CorpseScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, (CorpseEntity) null);
    }

    // Client-side constructor with buffer (for ExtendedScreenHandlerType)
    public CorpseScreenHandler(int syncId, class_1661 playerInventory, class_2540 buf) {
        this(syncId, playerInventory, (CorpseEntity) null);
    }

    // Server-side constructor
    public CorpseScreenHandler(int syncId, class_1661 playerInventory, CorpseEntity corpseEntityIn) {
        super(CorpseMod.CORPSE_SCREEN_HANDLER, syncId);
        this.corpseEntity = corpseEntityIn;

        int totalCorpseSlots = 41; // 36 main + 4 armor + 1 offhand
        this.corpseContainer = new class_1277(totalCorpseSlots);

        // Server: copy items from entity to container
        if (corpseEntity != null && !playerInventory.field_7546.method_37908().field_9236) {
            int idx = 0;
            for (int i = 0; i < 36; i++) {
                corpseContainer.method_5447(idx++, corpseEntity.getMainInventory().get(i).method_7972());
            }
            for (int i = 0; i < 4; i++) {
                corpseContainer.method_5447(idx++, corpseEntity.getArmorInventory().get(i).method_7972());
            }
            corpseContainer.method_5447(idx, corpseEntity.getOffHandInventory().get(0).method_7972());
        }

        // Corpse main inventory: 4 rows of 9 (slots 0-35)
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(corpseContainer, row * 9 + col, 8 + col * 18, 18 + row * 18));
            }
        }

        // Corpse armor + offhand row (slots 36-40)
        this.method_7621(new class_1735(corpseContainer, 36, 8, 94));   // Helmet
        this.method_7621(new class_1735(corpseContainer, 37, 26, 94));  // Chestplate
        this.method_7621(new class_1735(corpseContainer, 38, 44, 94));  // Leggings
        this.method_7621(new class_1735(corpseContainer, 39, 62, 94));  // Boots
        this.method_7621(new class_1735(corpseContainer, 40, 98, 94));  // Offhand

        // Player inventory: 3 rows of 9 (slots 41-67) — vanilla y=140
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }

        // Player hotbar: 1 row of 9 (slots 68-76) — vanilla y=198
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 198));
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 result = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);

        if (slot != null && slot.method_7681()) {
            class_1799 stackInSlot = slot.method_7677();
            result = stackInSlot.method_7972();

            if (index < 41) {
                // From corpse inventory to player inventory
                if (!this.method_7616(stackInSlot, 41, 77, true)) {
                    return class_1799.field_8037;
                }
            } else {
                // From player inventory to corpse inventory
                if (!this.method_7616(stackInSlot, 0, 41, false)) {
                    return class_1799.field_8037;
                }
            }

            if (stackInSlot.method_7960()) {
                slot.method_7673(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return result;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        if (corpseEntity != null) {
            return corpseEntity.method_5805() && player.method_5858(corpseEntity) <= 64.0;
        }
        return this.corpseContainer.method_5443(player);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);

        // Server side: sync container items back to entity
        if (!player.method_37908().field_9236 && corpseEntity != null && corpseEntity.method_5805()) {
            int idx = 0;
            for (int i = 0; i < 36; i++) {
                corpseEntity.getMainInventory().set(i, corpseContainer.method_5438(idx++).method_7972());
            }
            for (int i = 0; i < 4; i++) {
                corpseEntity.getArmorInventory().set(i, corpseContainer.method_5438(idx++).method_7972());
            }
            corpseEntity.getOffHandInventory().set(0, corpseContainer.method_5438(idx).method_7972());
        }
    }
}
