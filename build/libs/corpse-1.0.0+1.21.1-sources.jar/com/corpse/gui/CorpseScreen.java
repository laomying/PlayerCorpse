package com.corpse.gui;

import com.corpse.CorpseMod;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class CorpseScreen extends class_465<CorpseScreenHandler> {

    private static final class_2960 GUI_TEXTURE = class_2960.method_60656(
            "textures/gui/container/generic_54.png");

    public CorpseScreen(CorpseScreenHandler handler, class_1661 playerInventory, class_2561 title) {
        super(handler, playerInventory, title);
        this.field_2792 = 176;
        this.field_2779 = 222;
        this.field_25270 = this.field_2779 - 94; // 128 = above player inventory
        this.field_25267 = 8;
        this.field_25268 = 6;
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        int x = (this.field_22789 - this.field_2792) / 2;
        int y = (this.field_22790 - this.field_2779) / 2;
        guiGraphics.method_25302(GUI_TEXTURE, x, y, 0, 0, this.field_2792, this.field_2779);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        this.method_2380(guiGraphics, mouseX, mouseY);
    }
}
